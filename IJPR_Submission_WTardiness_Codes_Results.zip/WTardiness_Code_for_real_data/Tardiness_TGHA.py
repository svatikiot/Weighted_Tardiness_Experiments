import pandas as pd
import math, time, json, random, copy
import Tardiness_TGHA_ATCS
import Tardiness_CP
import Tardiness_TGHA_calculators

# noinspection PyTypeChecker
def heuristics(weights, process, setups, deadlines, num_workers, number_of_jobs, num_machines, tau, rho, p_avg, s_avg,
               W):
    # final_values = {}
    edd, edd_ls, slack, slack_ls, atcs, atcs_ls = {}, {}, {}, {}, {}, {}
    gen_d = {'Seq': {}, 'Sol': 0, 'Time': 0, 'Time_best': 0}
    gen_d_lbbd = {'Seq': {}, 'Obj': 0, 'Time': 0, 'Time_best': 0}
    edd['H'], edd['LBBD'], edd_ls['H'], edd_ls['LBBD'] = copy.deepcopy(gen_d), copy.deepcopy(
        gen_d_lbbd), gen_d.copy(), gen_d_lbbd.copy()
    slack['H'], slack['LBBD'], slack_ls['H'], slack_ls[
        'LBBD'] = gen_d.copy(), gen_d_lbbd.copy(), gen_d.copy(), gen_d_lbbd.copy()
    atcs['H'], atcs['LBBD'], atcs_ls['H'], atcs_ls[
        'LBBD'] = gen_d.copy(), gen_d_lbbd.copy(), gen_d.copy(), gen_d_lbbd.copy()
    if W == 0:
        assignment_start = time.time()
        job_dict, first_sol = Tardiness_TGHA_assignment.gh1_assignment_form2(process, setups)
        assignment_time = time.time() - assignment_start
        # final_values['First_Step_Makespan'] = first_sol

        start_time_edd = time.time()

        # sequence EDD
        m_sequence, m_tardiness = {}, {}
        for m in range(num_machines):
            m_sequence[m] = []
            if len(job_dict[m]) > 0:
                m_sequence[m], m_tardiness[m] = Tardiness_TGHA_sequence.sequence_dependent_edd(
                    job_dict[m], process.loc[:, m], setups[m], deadlines)

        edd['H']['Seq'] = m_sequence
        edd['LBBD']['Seq'] = m_sequence
        edd_ls['H']['Best_Seq'] = edd['H']['Seq']

        lbbd_start = time.time()
        ### Benders Calculation
        edd['LBBD']['Obj'] = round(
            Tardiness_TGHA_calculators.lbbd_calc(num_machines, m_sequence, process, setups, deadlines, weights), 3)

        lbbd_interval = time.time() - lbbd_start
        ##############################################################################################################
        # CALL CP function

        if num_machines > num_workers and num_workers > 0:

            edd['H']['Sol'] = round(
                Tardiness_CP.resources_cp(num_workers, m_sequence, process, setups, deadlines, weights, -1), 3)
        else:
            sol_df, edd['H']['Sol'] = Tardiness_TGHA_calculators.calculator(num_machines, m_sequence, process, setups,
                                                                            deadlines, weights)
        edd['H']['Sol'] = round(edd['H']['Sol'], 3)
        #############################################################################################################

        edd['H']['Time'] = round(time.time() - start_time_edd + assignment_time - lbbd_interval, 3)
        edd['H']['Time_best'] = edd['H']['Time']
        edd['LBBD']['Time'] = round(time.time() - start_time_edd + assignment_time, 3)
        edd['LBBD']['Time_best'] = edd['LBBD']['Time']
        # edd_ls['H']['Obj_v'] = edd['H']['Obj_v']
        '''
        # Start Local Search
    
        ls_time_edd = time.time()
        ext_swaps, int_swaps = 0, 0
        while ext_swaps <= 10 * number_of_machines:
            new_sol = Tardiness_TGHA_local_search.local_search_EDD_external(final_values['EDD+LS'], num_workers, setups,
                                                                            process,
                                                                            number_of_machines, deadlines)
            if new_sol['Final_Tardiness'] < final_values['EDD+LS']['Final_Tardiness']:
                final_values['EDD+LS']['Final_Tardiness'] = new_sol['Final_Tardiness']
                final_values['EDD+LS']['M_Seq'] = new_sol['M_Seq']
                final_values['EDD+LS']['Time_last_improved'] = time.time() - ls_time_edd + final_values['EDD']['Time']
    
        while int_swaps <= 10 * (math.ceil(number_of_jobs / number_of_machines)):
            new_sol = Tardiness_TGHA_local_search.local_search_EDD_internal(final_values['EDD+LS'], num_workers, setups,
                                                                            process,
                                                                            number_of_machines, deadlines)
            if new_sol['Final_Tardiness'] < final_values['EDD+LS']['Final_Tardiness']:
                final_values['EDD+LS']['Final_Tardiness'] = new_sol['Final_Tardiness']
                final_values['EDD+LS']['M_Seq'] = new_sol['M_Seq']
                final_values['EDD+LS']['Time_last_improved'] = time.time() - ls_time_edd + final_values['EDD']['Time']
    
        final_values['EDD+LS']['Time'] = time.time() - ls_time_edd + final_values["EDD"]["Time"]
    
        
        loom_tardiness = dict.fromkeys(range(number_of_machines), 0)
        final_solution['Tardiness'] = 0
        
        for i in final_solution.index:
            if i != 0:
                loom_tardiness[final_solution.loc[i, 'Machine']] += max(0, final_solution.loc[i, 'End'] - deadlines[i])
                final_solution.loc[i, 'Tardiness'] = max(0, final_solution.loc[i, 'End'] - deadlines[i])
        '''

        slack_time_start = time.time()
        # sequence min slack
        m_sequence, m_tardiness = {}, {}
        for m in range(num_machines):
            m_sequence[m] = []
            if len(job_dict[m]) > 0:
                m_sequence[m], m_tardiness[m] = Tardiness_TGHA_sequence.sequence_dependent_min_slack(
                    job_dict[m], process.loc[:, m], setups[m], deadlines)

        slack['H']['Seq'] = m_sequence
        slack['LBBD']['Seq'] = m_sequence
        slack_ls['H']['Best_Seq'] = slack['H']['Seq']

        lbbd_start = time.time()
        ### Benders Calculation
        slack['LBBD']['Obj'] = round(
            Tardiness_TGHA_calculators.lbbd_calc(num_machines, m_sequence, process, setups, deadlines, weights), 3)

        lbbd_interval = time.time() - lbbd_start

        ##############################################################################################################
        # CALL CP function

        if num_machines > num_workers and num_workers > 0:

            slack['H']['Sol'] = round(
                Tardiness_CP.resources_cp(num_workers, m_sequence, process, setups, deadlines, weights, -1), 3)
        else:
            sol_df, slack['H']['Sol'] = Tardiness_TGHA_calculators.calculator(num_machines, m_sequence, process, setups,
                                                                              deadlines, weights)
        slack['H']['Sol'] = round(slack['H']['Sol'], 3)
        #############################################################################################################

        slack['H']['Time'] = round(time.time() - slack_time_start + assignment_time - lbbd_interval, 3)
        slack['H']['Time_best'] = slack['H']['Time']
        slack['LBBD']['Time'] = round(time.time() - slack_time_start + assignment_time, 3)
        slack['LBBD']['Time_best'] = slack['LBBD']['Time']

        '''
        loom_tardiness = dict.fromkeys(range(number_of_machines), 0)
        final_solution['Tardiness'] = 0
    
        for i in final_solution.index:
            if i != 0:
                loom_tardiness[final_solution.loc[i, 'Machine']] += max(0, final_solution.loc[i, 'End'] - deadlines[i])
                final_solution.loc[i, 'Tardiness'] = max(0, final_solution.loc[i, 'End'] - deadlines[i])
    
    
    
        print(final_solution)
        print(loom_tardiness)
    
        # Start Local Search
        LS_solution = Tardiness_TGHA_local_search.local_search()
    
        final_values['Time_LS'] = time.time() - start
    
        '''

    # atcs Algorithm
    atcs_time_start = time.time()
    m_sequence = Tardiness_TGHA_ATCS.atcs_algorithm(number_of_jobs, num_machines, weights, process, setups, deadlines,
                                                    tau, rho,
                                                    p_avg, s_avg)

    atcs['H']['Seq'] = m_sequence
    atcs['LBBD']['Seq'] = m_sequence
    atcs_ls['H']['Best_Seq'] = atcs['H']['Seq']
    lbbd_interval = 0
    lbbd_start = time.time()
    '''
    ### Benders Calculation
    atcs['LBBD']['Obj'] = round(
        Tardiness_TGHA_calculators.lbbd_calc(num_machines, m_sequence, process, setups, deadlines, weights), 3)

    lbbd_interval = time.time() - lbbd_start
    '''
    ##############################################################################################################
    # CALL CP function

    if num_machines > num_workers and num_workers > 0:
        atcs['H']['Sol'] = round(
            Tardiness_CP.resources_cp(num_workers, m_sequence, process, setups, deadlines, weights, -1), 3)
    else:
        sol_df, atcs['H']['Sol'] = Tardiness_TGHA_calculators.calculator(num_machines, m_sequence, process, setups,
                                                                         deadlines, weights)
    atcs['H']['Sol'] = round(atcs['H']['Sol'], 3)
    #############################################################################################################

    atcs['H']['Time'] = round(time.time() - atcs_time_start - lbbd_interval, 3)
    atcs['H']['Time_best'] = atcs['H']['Time']
    atcs['LBBD']['Time'] = round(time.time() - atcs_time_start, 3)
    atcs['LBBD']['Time_best'] = atcs['LBBD']['Time']
    # return final values

    final_values = {'edd': edd, 'slack': slack, 'atcs': atcs}
    return final_values
