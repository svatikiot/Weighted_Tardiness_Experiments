import pandas as pd
import time, json, math
import Tardiness_GA_spawning, Tardiness_GA_fitness_calc, Tardiness_GA_crossover, Tardiness_TGHA_calculators

pd.options.mode.chained_assignment = None  # default='warn'


def genetic_alg(process, setups, deadlines, weights, num_workers, num_orders, num_machines):
    final_values = {}
    for pop_size in [10]:
        for generations in [10]:
            gen_counter = 0
            new_off = 0
            cut_cp = 0
            start_ga, lbbd_interval = time.time(), 0
            lbbd_warm_up = {'Obj': math.inf, 'Seq': {}, 'Time': 0}

            while gen_counter <= generations and time.time() - start_ga <= 3600:

                # GA initial population spawning
                if gen_counter == 0:
                    population = Tardiness_GA_spawning.spawning(pop_size, num_orders)

                    # Calculate fitness functions for initial population

                    for ch in population.keys():
                        population[ch], s_cut_cp = Tardiness_GA_fitness_calc.fitness_calc(population[ch], num_workers,
                                                                                          num_machines, process, setups,
                                                                                          deadlines, weights, -1)
                        cut_cp += s_cut_cp
                        '''
                        # Calculate LBBD master objective for initial population
                        lbbd_start = time.time()
                        lbbd_obj = Tardiness_TGHA_calculators.lbbd_calc(num_machines, population[ch]['Seq'], process,
                                                                        setups, deadlines, weights)
                        if lbbd_obj < lbbd_warm_up['Obj']:
                            lbbd_warm_up['Obj'] = round(lbbd_obj, 2)
                            lbbd_warm_up['Seq'] = population[ch]['Seq']

                        lbbd_interval += time.time() - lbbd_start
                        '''
                    population = dict(sorted(population.items(), key=lambda x: x[1]['Obj'])[:pop_size])
                    population = {i: v for i, v in enumerate(population.values())}
                    sol_cut_off = round(population[pop_size - 1]['Obj'], 2)
                # Crossover
                poss_parents = list(range(pop_size))  # candidate parents
                for ch in range(pop_size, pop_size * 2, 2):
                    population[ch], population[
                        ch + 1], poss_parents, child_exist = Tardiness_GA_crossover.crossover(population,
                                                                                              poss_parents,
                                                                                              num_machines,
                                                                                              num_orders)

                    if child_exist:
                        new_off += 2
                        population[ch], s_cut_cp = Tardiness_GA_fitness_calc.fitness_calc(population[ch], num_workers,
                                                                                          num_machines,
                                                                                          process, setups, deadlines,
                                                                                          weights, sol_cut_off)
                        cut_cp += s_cut_cp
                        population[ch + 1], s_cut_cp = Tardiness_GA_fitness_calc.fitness_calc(population[ch + 1],
                                                                                              num_workers,
                                                                                              num_machines, process,
                                                                                              setups,
                                                                                              deadlines, weights,
                                                                                              sol_cut_off)
                        cut_cp += s_cut_cp
                        '''
                        lbbd_start = time.time()

                        lbbd_obj = Tardiness_TGHA_calculators.lbbd_calc(num_machines, population[ch]['Seq'],
                                                                        process, setups, deadlines, weights)
                        if lbbd_obj < lbbd_warm_up['Obj']:
                            lbbd_warm_up['Obj'] = round(lbbd_obj, 2)
                            lbbd_warm_up['Seq'] = population[ch]['Seq']

                        lbbd_obj = Tardiness_TGHA_calculators.lbbd_calc(num_machines, population[ch + 1]['Seq'],
                                                                        process, setups, deadlines, weights)
                        if lbbd_obj < lbbd_warm_up['Obj']:
                            lbbd_warm_up['Obj'] = round(lbbd_obj, 2)
                            lbbd_warm_up['Seq'] = population[ch]['Seq']

                        lbbd_interval += time.time() - lbbd_start
                        '''
                # print(gen_counter, ' Gen_time: ', time.time() - start_ga - lbbd_interval)
                gen_counter += 1

                # Survival
                # print(lbbd_warm_up['Obj'])

                population = dict(sorted(population.items(), key=lambda x: x[1]['Obj'])[:pop_size])
                population = {i: v for i, v in enumerate(population.values())}
                sol_cut_off = round(population[pop_size - 1]['Obj'], 2)
                # print (population)
            solution = dict(sorted(population.items(), key=lambda x: x[1]['Obj'])[:1])
            # print (solution)
            end_ga = time.time()
            final_values['Seq'] = solution[0]['Seq']
            final_values['Sol'] = round(solution[0]['Obj'], 2)

            # final_values[instance]['Gap'] = (solution[0]['Obj'] - lower_bound) / lower_bound * 100
            final_values['Time'] = round(end_ga - start_ga - lbbd_interval, 3)
            lbbd_warm_up['Time'] = round(end_ga - start_ga, 3)

    for k in final_values['Seq']:
        final_values['Seq'][k] = [int(x) for x in final_values['Seq'][k]]
        # lbbd_warm_up['Seq'][k] = [int(x) for x in lbbd_warm_up['Seq'][k]]
    # sols = {'H': final_values, 'LBBD': lbbd_warm_up}
    sols = {'H': final_values}
    return sols, cut_cp, new_off, gen_counter
