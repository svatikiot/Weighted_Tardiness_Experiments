import math, random
import numpy as np
import pandas as pd
from datetime import datetime


# pd.set_option('display.max_columns', None, 'display.max_rows', None)

def resources_cp(num_workers, sequence, process_time_assgn, setups, deadlines, weights, sol_cut_off):
    obj_value = 100
    jobs = list([1, 2, 3, 4, 5])
    jobs_to_machines = [1, 0, 1, 0, 0]
    start_times = [2, 3, 4, 6, 7]
    end_times = [1, 4, 6, 6, 6]
    sol = [1, 3, 2, 4, 4]
    old_sol_df = np.column_stack((jobs, jobs_to_machines, start_times, end_times, sol))
    ######################## TO REMOVE AFTER CP IS ADDED #############################

    return obj_value


def resources_cp_with_sol(num_workers, sequence, process_time_assgn, setups, deadlines, weights):
    # print (setups)
    obj_value = 100
    jobs = list([1, 2, 3, 4, 5])
    jobs_to_machines = [1, 0, 1, 0, 0]
    start_times = [2, 3, 4, 6, 7]
    end_times = [1, 4, 6, 6, 100]
    sol = [100, 3, 2, 4, 10000]
    final_solution = np.column_stack((jobs, jobs_to_machines, start_times, end_times, sol))
    ######################## TO REMOVE AFTER CP IS ADDED #############################

    return obj_value, final_solution
