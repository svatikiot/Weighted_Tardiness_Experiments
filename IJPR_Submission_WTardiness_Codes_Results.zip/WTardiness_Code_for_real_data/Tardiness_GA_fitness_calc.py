import math, random
import Tardiness_CP
import numpy as np
import Tardiness_TGHA_calculators
import pandas as pd


def fitness_calc(chromosomes, num_workers, machines, process, setups, deadlines, weights, sol_cut_off):
    cut_cp = 0
    chromosomes['Obj'] = 0.0
    load, m_tardiness, last_order = dict.fromkeys(range(machines), 0.0), dict.fromkeys(range(machines), 0), dict.fromkeys(
        range(machines), 0)
    machine_seq, load_2 = {key: [] for key in list(range(machines))}, {key: math.inf for key in list(range(machines))}
    for j in range(len(chromosomes['Order'])):
        job = chromosomes['Order'][j]
        for m in range(machines):
            m_tardiness[m] = weights[job] * max(0, load[m] + process[job, m] + float(setups[m][last_order[m]][job]) -
                                                deadlines[job])

        min_tard = min(m_tardiness.values())
        min_machine = [k for k, v in m_tardiness.items() if v == min_tard]
        if len(min_machine) > 1:
            for m in min_machine:
                load_2[m] = load[m] + process[job, m] + float(setups[m][last_order[m]][job])
            min_load = min(load_2.values())
            min_machine = random.choice([k for k, v in load_2.items() if v == min_load])

        else:
            min_machine = min_machine[0]
        load[min_machine] += + process[job, min_machine] + float(setups[min_machine][last_order[min_machine]][job])
        last_order[min_machine] = job
        machine_seq[min_machine].append(job)
        chromosomes['Obj'] += weights[job] * max(0, load[min_machine] - deadlines[job])
    if num_workers < machines and num_workers > 0 and (chromosomes['Obj'] <= sol_cut_off or sol_cut_off < 0):
        chromosomes['Obj'] = Tardiness_CP.resources_cp(num_workers, machine_seq, process, setups, deadlines, weights,
                                                       sol_cut_off)
    elif chromosomes['Obj'] > sol_cut_off:
        cut_cp += 1
    chromosomes['Seq'] = machine_seq
    return chromosomes, cut_cp
