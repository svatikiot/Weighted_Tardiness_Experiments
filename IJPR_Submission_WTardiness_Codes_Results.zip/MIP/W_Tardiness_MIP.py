from __future__ import division
import sys
import random
import time
import math
#import cplex
import itertools
import gurobipy as gp
from pyomo.environ import *
import pandas as pd
import json
from csv import reader
import logging

print()
print("------------------------------------------------------------------------------------------------------------------------------")
logging.getLogger('pyomo.core').setLevel(logging.ERROR)

horizon = 50000
max_iterations = 1
time_limit = 3600
max_T = 1000

file1 = open('Benchmark_datasets_final_IJPR.json')
data1 = json.load(file1)
file2 = open('LBBD_BEST_Weights.json')
data2 = json.load(file2)
file_name = "Results.txt"
export_sequences = "Sequences.txt"

instances1 = []
for key in data1:
	instances1.append(key)

for ID in instances1:
	for key in data1[ID]:
		if key == "Number_of_jobs":
			jobs = int(data1[ID][key])
		if key == "Number_of_machines":
			machines = int(data1[ID][key])
		if key == "Alpha":
			alpha = int(data1[ID][key])
		if key == "Tau":
			tau = float(data1[ID][key])
		if key == "Rho":
			rho = float(data1[ID][key])
	deadlines = [0.0 for i in range(jobs)]
	processing_times = [[0.0 for m in range(machines)] for i in range(jobs)]
	setup_times = [[[0.0 for m in range(machines)] for j in range(jobs)] for i in range(jobs)]
	zero_setup = [[0.0 for m in range(machines)] for i in range(jobs)]
	weight = [0.0 for i in range(jobs)]
	for key in data1[ID]:
		if key == "Deadlines":
			for i in range(jobs):
				deadlines[i] = int(data1[ID][key][i+1])
				if deadlines[i] < 0:
					deadlines[i] = 0
		if key == "ProcessTimes":
			for m in data1[ID][key]:
				for i in range(jobs):
					processing_times[i][int(m)] = round(data1[ID][key][m][i+1], 2)
		if key == "SetupTimes":
			for m in data1[ID][key]:
				for i in range(jobs):
					for j in range(jobs):
						setup_times[i][j][int(m)] = data1[ID][key][m][i+1][j+1]
					zero_setup[i][int(m)] = data1[ID][key][m][0][i+1]
		if key == "Weights":
			for i in range(jobs):
				weight[i] = int(data1[ID][key][i+1])
	s_min = [[0.0 for m in range(machines)] for i in range(jobs)]
	for i in range(jobs):
		for m in range(machines):
			new_list = []
			for j in range(jobs):
				if i != j:
					new_list.append(setup_times[j][i][m])
			s_min[i][m] = min(new_list)

	if jobs == 25 and machines == 5:
		for name in data2:
			if ID in name:
				instance_id = name

				sequences = []
				try:
					for key in data2[name]['H']:
						if key == "Seq":
							for m in data2[name]['H'][key]:
								sequences.append(data2[name]['H'][key][m])
						if key == "Upper_bound":
							heuristic = data2[name][key]
						if key == "Time":
							bound_time = data2[name]['H'][key]
				except:
					for key in data2[name]:
						if key == "Seq":
							for m in data2[name][key]:
								sequences.append(data2[name][key][m])
						if key == "Upper_bound":
							heuristic = data2[name][key]
						if key == "Time":
							bound_time = data2[name][key]
				for m in range(machines):
					for i in range(len(sequences[m])):
						sequences[m][i] = sequences[m][i] - 1

				f_x = [[[0.0 for m in range(machines)] for j in range(jobs)] for i in range(jobs)]
				f_y = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_f = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_P = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_S = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_C = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_D = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_T = [[0.0 for m in range(machines)] for j in range(jobs)]
				f_W = [[[[0.0 for t in range(int(max_T/10))] for m in range(machines)] for j in range(jobs)] for i in range(jobs)]
				f_z = 0.0

				for m in range(machines):
					timeline = 0
					for i in range(len(sequences[m])):
						f_x[jobs - len(sequences[m]) + i][sequences[m][i]][m] = 1.0
						f_y[sequences[m][i]][m] = 1.0
						if i == 0:
							f_f[jobs - len(sequences[m]) + i][m] = 1.0
						f_P[jobs - len(sequences[m]) + i][m] = processing_times[sequences[m][i]][m]
						if i == 0:
							f_S[jobs - len(sequences[m]) + i][m] = zero_setup[sequences[m][i]][m]
							f_C[jobs - len(sequences[m]) + i][m] = f_P[jobs - len(sequences[m]) + i][m] + f_S[jobs - len(sequences[m]) + i][m]
							timeline = timeline + f_C[jobs - len(sequences[m]) + i][m]
							f_D[jobs - len(sequences[m]) + i][m] = deadlines[sequences[m][i]]
							f_T[jobs - len(sequences[m]) + i][m] = max(0, timeline - f_D[jobs - len(sequences[m]) + i][m])
							for t in range(int(max_T/10)):
								if 10*t >= f_T[jobs - len(sequences[m]) + i][m]:
									f_W[jobs - len(sequences[m]) + i][sequences[m][i]][m][t] = 1.0
									f_z = f_z + weight[sequences[m][i]]*10*t
									break
						else:
							#f_S[jobs - len(sequences[m]) + i][m] = max([s_plus[sequences[m][i]][m], s_minus[sequences[m][i-1]][m]])
							f_S[jobs - len(sequences[m]) + i][m] = s_min[sequences[m][i]][m]
							f_C[jobs - len(sequences[m]) + i][m] = timeline + f_P[jobs - len(sequences[m]) + i][m] + f_S[jobs - len(sequences[m]) + i][m]
							timeline = timeline + f_C[jobs - len(sequences[m]) + i][m]
							f_D[jobs - len(sequences[m]) + i][m] = deadlines[sequences[m][i]]
							f_T[jobs - len(sequences[m]) + i][m] = max(0, timeline - f_D[jobs - len(sequences[m]) + i][m])
							for t in range(int(max_T/10)):
								if 10*t >= f_T[jobs - len(sequences[m]) + i][m]:
									f_W[jobs - len(sequences[m]) + i][sequences[m][i]][m][t] = 1.0
									f_z = f_z + weight[sequences[m][i]]*10*t
									break

				with open(file_name, 'a') as output:
					with open(export_sequences, 'a') as export:
						big_M = horizon
						print("Instance : "+str(instance_id)+"|	Jobs : "+str(jobs)+",	Machines : "+str(machines)+",	Alpha : "+str(alpha)+",	Tau : "+str(tau)+",	Rho : "+str(rho))
						print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")

						start_time = time.time()
						master_start = time.time()

						master = ConcreteModel()
						master.Jobs = range(jobs)
						master.Slots = range(jobs)
						master.Machines = range(machines)
						master.Intervals = range(int(max_T/10))

						master.z = Var(within = NonNegativeReals, initialize = 0.0)
						def obj_rule(model):
							return model.z
						# 0-1 Variables
						master.y = Var(master.Jobs, master.Machines, within = Binary, initialize = 0.0)
						master.x = Var(master.Slots, master.Jobs, master.Machines, within = Binary, initialize = 0.0)
						master.f = Var(master.Slots, master.Machines, within = Binary, initialize = 0.0)
						# Continuous Variables
						master.P = Var(master.Slots, master.Machines, within = NonNegativeReals, initialize = 0.0)
						master.S = Var(master.Slots, master.Machines, within = NonNegativeReals, initialize = 0.0)
						master.C = Var(master.Slots, master.Machines, within = NonNegativeReals, initialize = 0.0)
						master.D = Var(master.Slots, master.Machines, within = NonNegativeReals, initialize = 0.0)
						master.T = Var(master.Slots, master.Machines, within = NonNegativeReals, initialize = 0.0)
						master.W = Var(master.Slots, master.Jobs, master.Machines, master.Intervals, within = Binary, initialize = 0.0)

						for j in master.Jobs:
							for m in master.Machines:
								master.y[j, m] = f_y[j][m]
						for i in master.Slots:
							for j in master.Jobs:
								for m in master.Machines:
									master.x[i, j, m] = f_x[i][j][m]
						for i in master.Slots:
							for m in master.Machines:
								master.f[i, m] = f_f[i][m]
								master.P[i, m] = f_P[i][m]
								master.S[i, m] = f_S[i][m]
								master.C[i, m] = f_C[i][m]
								master.D[i, m] = f_D[i][m]
								master.T[i, m] = f_T[i][m]
								for j in master.Jobs:
									for t in master.Intervals:
										master.W[i, j, m, t] = f_W[i][j][m][t]
						master.z = f_z

						master.obj = Objective(rule = obj_rule, sense = minimize)
						master.constraints = ConstraintList()

						for j in master.Jobs:
							master.constraints.add(sum(master.y[j,m] for m in master.Machines) == 1.0)
							for m in master.Machines:
								master.constraints.add(sum(master.x[i,j,m] for i in master.Slots) == master.y[j,m])
						for m in master.Machines:
							for i in master.Slots:
								master.constraints.add(sum(master.x[i,j,m] for j in master.Jobs) <= 1.0)
							master.constraints.add(sum(master.f[i,m] for i in master.Slots) == 1.0)
							for i in master.Slots:
								if i > 0:
									master.constraints.add(sum(master.x[i,j,m] for j in master.Jobs) >= sum(master.x[i-1,j,m] for j in master.Jobs))
									master.constraints.add(sum(master.x[i-1,j,m] for j in master.Jobs) <= master.f[i,m] + 1)
									master.constraints.add(master.C[i,m] == master.C[i-1,m] + master.P[i,m] + master.S[i,m])
								master.constraints.add(master.D[i,m] == sum(deadlines[j]*master.x[i,j,m] for j in master.Jobs))
								master.constraints.add(master.T[i,m] >= master.C[i,m] - master.D[i,m])
								master.constraints.add(master.P[i,m] == sum(processing_times[j][m]*master.x[i,j,m] for j in master.Jobs))
								for j in master.Jobs:
									master.constraints.add(sum(master.W[i,j,m,t] for t in master.Intervals) == master.x[i,j,m])
								master.constraints.add(sum(10*t*master.W[i,j,m,t] for j in master.Jobs for t in master.Intervals) >= master.T[i,m])
								master.constraints.add(master.S[i,m] >= sum(s_min[j][m]*master.x[i,j,m] for j in master.Jobs) - big_M*master.f[i,m])

						master.constraints.add(master.z >= sum(weight[j]*10*t*master.W[i,j,m,t] for i in master.Slots for j in master.Jobs for m in master.Machines for t in master.Intervals))

						M = SolverFactory('gurobi_direct')
						M.options['threads'] = 1
						M.options['timelimit'] = time_limit
						results_obj = M.solve(master, tee = False, warmstart = True)

						lower_bound = round(results_obj.Problem._list[0].lower_bound, 2)
						max_lb = round(value(master.z), 2)

						master_end = time.time()
						master_time = master_end - master_start

						neighbourhood = []
						for m in range(machines):
							neighbourhood.append([])
							for i in range(jobs):
								for j in range(jobs):
									if value(master.x[i,j,m]) > 0.9:
										neighbourhood[m].append(j)
						export.write(str(neighbourhood)+",\n")
						end_time = time.time()

						output.write(str(instance_id)+";"+str(lower_bound)+";"+str(max_lb)+";"+str(round(end_time - start_time, 2))+"\n")
						print("-----------------------------------------------------------------------------------------")
						export.close()
					output.close()
					
					