import math
import random
import Tardiness_GA_fix_chromosomes


def crossover(chromosomes, poss_parents, m_machines, j_jobs):
    # choose parents
    p_1, p_2 = random.sample(poss_parents, 2)
    parent_1 = chromosomes[p_1]
    parent_2 = chromosomes[p_2]
    child_exist = True
    if random.random() < 0.5:
        # find splitting point on chromosomes
        split_pos = random.randint(1, min(len(parent_1['Order']), len(parent_2['Order'])) - 2)
        # create new chromosomes for children
        child_1 = {'Order': parent_1['Order'][:split_pos + 1] + parent_2['Order'][split_pos + 1:]}
        # rest_child_1 = {'Order': parent_2['Order'][split_pos + 1:], 'Perc': parent_2['Perc'][split_pos + 1:]}
        child_2 = {'Order': parent_2['Order'][:split_pos + 1] + parent_1['Order'][split_pos + 1:]}
        # rest_child_2 = {'Order': parent_1['Order'][split_pos + 1:], 'Perc': parent_1['Perc'][split_pos + 1:]}

        # fix child_1
        child_1 = Tardiness_GA_fix_chromosomes.fix_chromosomes(child_1, j_jobs, split_pos)

        # fix child_2
        child_2 = Tardiness_GA_fix_chromosomes.fix_chromosomes(child_2, j_jobs, split_pos)

        # Mutation

        if random.random() < 0.15:
            pos1 = random.randint(0, len(child_1['Order']) - 1)
            pos2 = random.choice(list(range(0, pos1)) + list(range(pos1 + 1, len(child_1['Order']) - 1)))
            child_1['Order'][pos1], child_1['Order'][pos2] = child_1['Order'][pos2], child_1['Order'][pos1]

        if random.random() < 0.15:
            pos1 = random.randint(0, len(child_2['Order']) - 1)
            pos2 = random.choice(list(range(0, pos1)) + list(range(pos1 + 1, len(child_2['Order']) - 1)))
            child_2['Order'][pos1], child_2['Order'][pos2] = child_2['Order'][pos2], child_2['Order'][pos1]

    else:
        child_1 = {'Obj': math.inf}
        child_2 = {'Obj': math.inf}
        child_exist = False
    poss_parents = list(set(poss_parents) - set([p_1, p_2]))
    return child_1, child_2, poss_parents, child_exist
