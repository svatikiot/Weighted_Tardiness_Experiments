import json, copy, math, time, sys
import Tardiness_TGHA, Tardiness_SA, Tardiness_GA_main
import pandas as pd
import numpy as np
import csv

if __name__ == "__main__":
    W = 1
    # W = int(sys.argv[1])
    start = time.time()
    final_sols, lbbd_sols = {}, {}
    edd, slack, atcs, ga, sa_ga, sa_atcs, sa_edd, sa_slack = {}, {}, {}, {}, {}, {}, {}, {}
    f = open(
        r"Benchmark_datasets_final_IJPR.json", )
    data = json.load(f)
    if W == 0:
        columns = pd.DataFrame(
            ["Instance_Number", "Instance", "J", "M", "R", "A", "Tau", "Rho", "P_avg", "S_avg", "h", "GA_sol",
             "GA_time", "GA_LBBD_sol", "GA_LBBD_time",
             "ATCS_sol", "ATCS_time", "ATCS_LBBD_sol", "ATCS_LBBD_time", "EDD_sol", "EDD_time", "EDD_LBBD_sol",
             "EDD_LBBD_time",
             "SLACK_sol", "SLACK_time",
             "SLACK_LBBD_sol", "SLACK_LBBD_time", "SLACK+SA_sol", "SLACK+SA_time", "SLACK+SA_LBBD_sol",
             "SLACK+SA_LBBD_time"]).T
        '''
        columns = pd.DataFrame(
            ["Instance_Number", "Instance", "J", "M", "R", "A", "Tau", "Rho", "P_avg", "S_avg", "h", "GA_sol",
             "GA_time", "GA_LBBD_sol", "GA_LBBD_time", "GA+SA_sol", "GA+SA_time", "GA+SA_LBBD_sol", "GA+SA_LBBD_time",
             "ATCS_sol", "ATCS_time", "ATCS_LBBD_sol", "ATCS_LBBD_time", "ATCS+SA_sol", "ATCS+SA_time",
             "ATCS+SA_LBBD_sol", "ATCS+SA_LBBD_time", "EDD_sol", "EDD_time", "EDD_LBBD_sol", "EDD_LBBD_time",
             "EDD+SA_sol", "EDD+SA_time", "EDD+SA_LBBD_sol", "EDD+SA_LBBD_time", "SLACK_sol", "SLACK_time",
             "SLACK_LBBD_sol", "SLACK_LBBD_time", "SLACK+SA_sol", "SLACK+SA_time", "SLACK+SA_LBBD_sol",
             "SLACK+SA_LBBD_time"]).T
        '''
        with open("Experiments_Tardiness_Benchmark_No_Weights.csv", 'a', newline='') as f:
            columns.to_csv(f, header=False, index=False)
    else:
        '''
        columns = pd.DataFrame(
            ["Instance_Number", "Instance", "J", "M", "R", "A", "Tau", "Rho", "P_avg", "S_avg", "h", "GA_sol",
             "GA_time", "GA_LBBD_sol", "GA_LBBD_time", "GA+SA_sol", "GA+SA_time", "GA+SA_LBBD_sol", "GA+SA_LBBD_time",
             "ATCS_sol", "ATCS_time", "ATCS_LBBD_sol", "ATCS_LBBD_time", "ATCS+SA_sol", "ATCS+SA_time",
             "ATCS+SA_LBBD_sol", "ATCS+SA_LBBD_time"]).T
        '''
        with open('Experiments_Tardiness_Benchmark_Weights_Real.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(
                ["Instance_Number", "Instance", "J", "M", "R", "Tau", "Rho", "P_avg", "S_avg", "h", "GA_sol",
                 "GA_time", "CP_CUT", "TOTAL_CP", "GENS", "ATCS_sol", "ATCS_time"])
    # loop over all instances in json
    for instance_number in data.keys():
        # reading from instance json
        number_of_jobs, number_of_machines = data[instance_number]['Number_of_jobs'], data[instance_number][
            'Number_of_machines']
        alpha, tau, rho = data[instance_number]['Alpha'], data[instance_number]['Tau'], data[instance_number]['Rho']
        p_avg, s_avg = data[instance_number]['P_avg'], data[instance_number]['S_avg']
        # if number_of_machines == 2 and number_of_jobs == 20 and alpha == 0 and rho == 0.2 and tau == 0.5:
        if instance_number == "1670341355.9356968":
            process = np.array(list(data[instance_number]['ProcessTimes'].values())).T
            setups = {}
            for m in data[instance_number]['SetupTimes'].keys():
                setups[int(m)] = np.array(list(data[instance_number]['SetupTimes'][str(m)]))
            deadlines = {k: v for k, v in enumerate(data[instance_number]['Deadlines'])}
            print(deadlines)
            if W == 1:
                weights = {k: v for k, v in enumerate(data[instance_number]['Weights'])}
            else:
                weights = {j: 1 for j in range(number_of_jobs + 1)}
            print (weights)
            for number_of_workers in [number_of_machines]:
                for it in range(10):
                    print(
                        f"Instance {instance_number} for Jobs: {number_of_jobs}, Machines: {number_of_machines}, "
                        f"Workers: {number_of_workers}, alpha {alpha}, Rho {rho}, Tau {tau}")
                    instance = str(instance_number) + "-Work" + str(number_of_workers)
                    gen_dict = {'J': number_of_jobs, 'M': number_of_machines, 'W': number_of_workers,
                                'A': alpha, "Tau": tau, "Rho": rho, "P_avg": p_avg, "S_avg": s_avg,
                                "h": round(s_avg / p_avg, 3)}
                    ga_sol, cut_cp, new_off, gen_counter = Tardiness_GA_main.genetic_alg(process, setups, deadlines,
                                                                                         weights,
                                                                                         number_of_workers,
                                                                                         number_of_jobs,
                                                                                         number_of_machines)
                    print (ga_sol)

                    sa_sol_ga = Tardiness_SA.simulated_annealing(ga_sol, process, setups, deadlines, weights,
                                                                 number_of_workers, number_of_machines)

                    heur_sol = Tardiness_TGHA.heuristics(weights, process, setups, deadlines, number_of_workers,
                                                         number_of_jobs, number_of_machines, tau, rho, p_avg,
                                                         s_avg, W)
                    # print (heur_sol)

                    sa_sol_atcs = Tardiness_SA.simulated_annealing(heur_sol['atcs'], process, setups, deadlines,
                                                                   weights,
                                                                   number_of_workers,
                                                                   number_of_machines)

                    # ga[instance] = gen_dict | ga_sol
                    ga[instance] = {**gen_dict, **ga_sol}
                    # final_sols[instance], lbbd_sols[instance] = copy.deepcopy(ga[instance]), copy.deepcopy(lbbd_ga)
                    atcs[instance] = {**gen_dict, **heur_sol['atcs']}
                    # atcs[instance] = gen_dict | heur_sol['atcs']
                    sa_ga[instance] = {**gen_dict, **sa_sol_ga['H']}
                    sa_atcs[instance] = {**gen_dict, **sa_sol_atcs['H']}
                    lbbd_sols[instance] = copy.deepcopy(ga[instance])
                    lbbd_sols[instance]['Best_H'] = 'GA'
                    lbbd_value = ga_sol['H']['Sol']
                    if sa_sol_ga['H']['Sol'] < lbbd_value:
                        lbbd_sols[instance] = copy.deepcopy(sa_ga[instance])
                        lbbd_sols[instance]['Best_H'] = 'GA_SA'
                    if heur_sol['atcs']['H']['Sol'] < lbbd_value:
                        lbbd_sols[instance] = copy.deepcopy(atcs[instance])
                        lbbd_sols[instance]['Best_H'] = 'ATCS'
                    if sa_sol_atcs['H']['Sol'] < lbbd_value:
                        lbbd_sols[instance] = copy.deepcopy(sa_atcs[instance])
                        lbbd_sols[instance]['Best_H'] = 'ATCS_SA'
                    if W == 0:
                        '''
                        sa_sol_edd = Tardiness_SA.simulated_annealing(heur_sol['edd'], process, setups, deadlines,
                                                                      weights, number_of_workers,
                                                                      number_of_machines)
                        sa_sol_slack = Tardiness_SA.simulated_annealing(heur_sol['slack'], process, setups, deadlines,
                                                                        weights, number_of_workers,
                                                                        number_of_machines)
                        '''
                        edd[instance] = gen_dict | heur_sol['edd']
                        slack[instance] = gen_dict | heur_sol['slack']
                        # sa_edd[instance] = gen_dict | sa_sol_edd
                        # sa_slack[instance] = gen_dict | sa_sol_slack
                        if heur_sol['edd']['LBBD']['Obj'] < lbbd_sols[instance]['Obj']:
                            lbbd_sols[instance] = copy.deepcopy(edd[instance]['LBBD'])
                            lbbd_sols[instance]['Best_H'] = 'EDD'
                        if heur_sol['slack']['LBBD']['Obj'] < lbbd_sols[instance]['Obj']:
                            lbbd_sols[instance] = copy.deepcopy(edd[instance]['LBBD'])
                            lbbd_sols[instance]['Best_H'] = 'SLACK'
                        '''
                        if sa_sol_edd['LBBD']['Obj'] < lbbd_sols[instance]['Obj']:
                            lbbd_sols[instance] = copy.deepcopy(sa_sol_edd[instance]['LBBD'])
                            lbbd_sols[instance]['Best_H'] = 'SA_EDD'
                        if sa_sol_slack['LBBD']['Obj'] < lbbd_sols[instance]['Obj']:
                            lbbd_sols[instance] = copy.deepcopy(sa_sol_slack[instance]['LBBD'])
                            lbbd_sols[instance]['Best_H'] = 'SA_SLACK'
                        '''
                    if W == 0:
                        '''
                        results = [instance_number, instance, number_of_jobs, number_of_machines, number_of_workers, alpha,
                                   tau, rho, p_avg, s_avg, round(s_avg / p_avg, 3), ga_sol['H']['Sol'], ga_sol['H']['Time'],
                                   ga_sol['LBBD']['Obj'], ga_sol['LBBD']['Time'], sa_sol_ga['H']['Sol'],
                                   sa_sol_ga['H']['Time'], sa_sol_ga['LBBD']['Obj'], sa_sol_ga['LBBD']['Time'],
                                   atcs[instance]['H']['Sol'], atcs[instance]['H']['Time'],
                                   atcs[instance]['LBBD']['Obj'], atcs[instance]['LBBD']['Time'],
                                   sa_sol_atcs['H']['Sol'], sa_sol_atcs['H']['Time'],
                                   sa_sol_atcs['LBBD']['Obj'], sa_sol_atcs['LBBD']['Time'],
                                   edd[instance]['H']['Sol'], edd[instance]['H']['Time'], edd[instance]['LBBD']['Obj'],
                                   edd[instance]['LBBD']['Time'], sa_edd[instance]['H']['Sol'],
                                   sa_edd[instance]['H']['Time'], sa_edd[instance]['LBBD']['Obj'],
                                   sa_edd[instance]['LBBD']['Time'], slack[instance]['H']['Sol'],
                                   slack[instance]['H']['Time'], slack[instance]['LBBD']['Obj'],
                                   slack[instance]['LBBD']['Time'], sa_slack[instance]['H']['Sol'],
                                   sa_slack[instance]['H']['Time'], sa_slack[instance]['LBBD']['Obj'],
                                   sa_slack[instance]['LBBD']['Time']]
                        '''
                        results = [instance_number, instance, number_of_jobs, number_of_machines, number_of_workers,
                                   alpha,
                                   tau, rho, p_avg, s_avg, round(s_avg / p_avg, 3), ga_sol['H']['Sol'],
                                   ga_sol['H']['Time'],
                                   ga_sol['LBBD']['Obj'], ga_sol['LBBD']['Time'],
                                   atcs[instance]['H']['Sol'], atcs[instance]['H']['Time'],
                                   atcs[instance]['LBBD']['Obj'], atcs[instance]['LBBD']['Time'],
                                   edd[instance]['H']['Sol'], edd[instance]['H']['Time'], edd[instance]['LBBD']['Obj'],
                                   edd[instance]['LBBD']['Time'], slack[instance]['H']['Sol'],
                                   slack[instance]['H']['Time'], slack[instance]['LBBD']['Obj'],
                                   slack[instance]['LBBD']['Time']]
                        results = pd.DataFrame([results])
                        with open("Experiments_Tardiness_Benchmark_No_Weights.csv", 'a', newline='') as f:
                            results.to_csv(f, header=False, index=False)
                    else:
                        '''
                        results = [instance_number, instance, number_of_jobs, number_of_machines, number_of_workers, alpha,
                                   tau, rho, p_avg, s_avg, round(s_avg / p_avg, 3), ga_sol['H']['Sol'], ga_sol['H']['Time'],
                                   ga_sol['LBBD']['Obj'], ga_sol['LBBD']['Time'], sa_sol_ga['H']['Sol'],
                                   sa_sol_ga['H']['Time'], sa_sol_ga['LBBD']['Obj'], sa_sol_ga['LBBD']['Time'],
                                   atcs[instance]['H']['Sol'], atcs[instance]['H']['Time'],
                                   atcs[instance]['LBBD']['Obj'], atcs[instance]['LBBD']['Time'],
                                   sa_sol_atcs['H']['Sol'], sa_sol_atcs['H']['Time'],
                                   sa_sol_atcs['LBBD']['Obj'], sa_sol_atcs['LBBD']['Time']]
                        '''

                        results = [instance_number, instance, number_of_jobs, number_of_machines, number_of_workers,
                                   tau, rho, p_avg, s_avg, round(s_avg / p_avg, 3), ga_sol['H']['Sol'],
                                   ga_sol['H']['Time'],
                                   cut_cp, new_off, gen_counter - 1, atcs[instance]['H']['Sol'],
                                   atcs[instance]['H']['Time']]

                        with open('Experiments_Tardiness_Benchmark_Weights_Real.csv', 'a', newline='') as file:
                            writer = csv.writer(file)
                            writer.writerow(results)
                    print(time.time() - start)
    if W == 1:

        with open("SA_GA_Weights.json", "w") as outfile:
            json.dump(sa_ga, outfile)

        with open("SA_ATCS_Weights.json", "w") as outfile:
            json.dump(sa_atcs, outfile)

        with open("GA_Weights.json", "w") as outfile:
            json.dump(ga, outfile)

        with open("ATCS_Weights.json", "w") as outfile:
            json.dump(atcs, outfile)

    if W == 0:
        with open("LBBD_BEST.json", "w") as outfile:
            json.dump(lbbd_sols, outfile)
        '''
        with open("SA_GA.json", "w") as outfile:
            json.dump(sa_ga, outfile)

        with open("SA_ATCS.json", "w") as outfile:
            json.dump(sa_atcs, outfile)
        '''
        with open("GA.json", "w") as outfile:
            json.dump(ga, outfile)

        with open("ATCS.json", "w") as outfile:
            json.dump(atcs, outfile)

        with open("SLACK_TGHA.json", "w") as outfile:
            json.dump(slack, outfile)

        with open("EDD_TGHA.json", "w") as outfile:
            json.dump(edd, outfile)
        '''
        with open("SA_EDD.json", "w") as outfile:
            json.dump(sa_edd, outfile)

        with open("SA_SLACK.json", "w") as outfile:
            json.dump(sa_slack, outfile)
        '''
