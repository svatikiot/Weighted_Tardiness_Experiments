import math
import random
import numpy as np
import pandas as pd
from datetime import datetime
import numpy.ma as ma


def lbbd_calc(num_machines, current_seq, process, setups, deadlines, weights):
    # Solution for LBBD Master

    previous_order = 0
    obj_v = 0
    for m in range(num_machines):
        setups_mx = ma.masked_array(setups[m], mask=setups[m] == 0)
        load = 0
        if len(current_seq[m]) > 0:
            load = process[current_seq[m][0], m]
            obj_v += weights[current_seq[m][0]] * max(0, load - deadlines[current_seq[m][0]])
            previous_order = current_seq[m][0]
        if len(current_seq[m]) > 1:
            for i in current_seq[m][1:]:
                load += process[i, m] + max(setups_mx[:, i].min(),
                                            np.min(setups_mx[previous_order].min()))
                obj_v += weights[i] * max(0, load - deadlines[i])
                previous_order = i
    return obj_v


def calculator(number_of_machines, current_seq, process, setups, deadlines, weights):
    # 1: Job 2: Machine 3: Start 4: End 5: Tardiness
    # Solution without Resources

    # sol_df = pd.DataFrame(index=[], columns=['Job', 'Machine', 'Start', 'End', 'Tardiness'])
    sol_df = np.zeros((0, 5),float)
    machine_tard = 0
    for m in range(number_of_machines):
        previous_load, previous_order = 0, 0
        for i in current_seq[m]:
            row = [[int(i), int(m), previous_load, previous_load + setups[m][previous_order][i] + process[i, m],
                   weights[i] * max(0,
                                    previous_load + process[i, m] + setups[m][previous_order][
                                        i] - deadlines[
                                        i])]]
            sol_df = np.append(sol_df, row, axis=0)
            machine_tard += weights[i] * max(0,
                                             previous_load + process[i, m] + setups[m][previous_order][i] - deadlines[
                                                 i])
            previous_load = previous_load + setups[m][previous_order][i] + process[i, m]
            previous_order = i
    return sol_df, machine_tard
