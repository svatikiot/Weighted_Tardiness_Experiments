import math
import numpy as np
#import Weighted_Tardiness_GA_earliest_time
from collections import Counter


def fix_chromosomes(child, jobs, split_pos):
    for i in range(1, jobs + 1):
        pos_i = np.where(np.array(child['Order']) == i)[0]
        if len(pos_i) == 0:
            child['Order'].insert(split_pos + 1, i)
        elif len(pos_i) > 1:
            while len(pos_i) > 1:
                del child['Order'][pos_i[0]]
                pos_i = np.where(np.array(child['Order']) == i)[0]

    return child
