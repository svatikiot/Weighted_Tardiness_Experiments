import math, time, random, copy
import numpy as np
from collections import Counter
import Tardiness_TGHA_calculators
import Tardiness_CP
import pandas as pd
import numpy.ma as ma

pd.set_option('display.max_columns', None, 'display.max_rows', None)


def simulated_annealing(init_sol, process, setups, deadlines, weights, num_workers, number_of_machines):
    lbbd_interval = 0
    count = 0
    #lbbd_best = {'Obj': init_sol['LBBD']['Obj'], 'best_Temp': -4000, 'improved': 0, 'Seq': init_sol['LBBD']['Seq']}
    sa_best = {'Sol': init_sol['H']['Sol'], 'best_Temp': -4000, 'improved': 0, 'Seq': init_sol['H']['Seq']}
    old_sol = {'Seq': init_sol['H']['Seq']}

    if number_of_machines > num_workers and num_workers > 0:
        old_sol['Sol'], old_sol_df = Tardiness_CP.resources_cp_with_sol(num_workers, old_sol['Seq'], process, setups,
                                                                        deadlines, weights)
    else:
        old_sol_df, old_sol['Sol'] = Tardiness_TGHA_calculators.calculator(number_of_machines, old_sol['Seq'], process,
                                                                           setups, deadlines,
                                                                           weights)


    Tc, Tcry, q, IT, sa_iter = 500, 1, 0.99, 100, 0
    start_time = time.time()
    ext = 1
    while Tcry < Tc:
        for it in range(IT):
            count += 1
            if ext == 1:
                new_seq = new_neighborhood_ext(number_of_machines, old_sol_df, old_sol['Seq'])
                if number_of_machines > num_workers and num_workers > 0:
                    obj_value, new_sol_df = Tardiness_CP.resources_cp_with_sol(num_workers, new_seq, process, setups,
                                                                               deadlines, weights)
                else:
                    new_sol_df, obj_value = Tardiness_TGHA_calculators.calculator(number_of_machines, new_seq, process,
                                                                                  setups, deadlines,
                                                                                  weights)
                obj_value = round(obj_value, 3)
                ext = 0
            else:
                new_seq = new_neighborhood_int(number_of_machines, old_sol_df, old_sol['Seq'])
                if number_of_machines > num_workers and num_workers > 0:
                    obj_value, new_sol_df = Tardiness_CP.resources_cp_with_sol(num_workers, new_seq, process, setups,
                                                                               deadlines, weights)
                else:
                    new_sol_df, obj_value = Tardiness_TGHA_calculators.calculator(number_of_machines, new_seq,
                                                                                  process, setups, deadlines,
                                                                                  weights)
                obj_value = round(obj_value, 3)

                ext = 1
            '''
            lbbd_start = time.time()
            lbbd_v = Tardiness_TGHA_calculators.lbbd_calc(number_of_machines, new_seq, process, setups, deadlines,
                                                          weights)
            if lbbd_v < lbbd_best['Obj']:
                lbbd_best['Seq'] = copy.deepcopy(new_seq)
                lbbd_best['Obj'] = lbbd_v
                lbbd_best['improved'] = 1
                lbbd_best['best_Temp'] = Tc
                lbbd_best['best_Time'] = round(time.time() - start_time, 3)
            lbbd_interval += time.time() - lbbd_start
            '''
            new_sol = {'Seq': new_seq, 'Sol': obj_value}
            Pacc = math.exp((old_sol['Sol'] - new_sol['Sol'])/ Tc)
            if new_sol['Sol'] < sa_best['Sol']:
                old_sol = copy.deepcopy(new_sol)
                old_sol_df = copy.deepcopy(new_sol_df)
                sa_best = {'Sol': round(new_sol['Sol'], 3), 'best_Temp': Tc, 'improved': 1, 'Seq': new_sol['Seq'],
                           'Time_Best': round(time.time() - start_time - lbbd_interval, 3)}
            elif new_sol['Sol'] < old_sol['Sol'] or Pacc > random.random():
                old_sol = copy.deepcopy(new_sol)
                old_sol_df = copy.deepcopy(new_sol_df)
        Tc = Tc * q

    sa_best['Time'] = time.time() - start_time - lbbd_interval
    #lbbd_best['Time'] = time.time() - start_time
    #sa = {'H': sa_best, 'LBBD': lbbd_best}
    sa = {'H': sa_best}
    return sa


def new_neighborhood_ext(number_of_machines, current_sol_df, old_seq):
    m_tardiness, m_load = {}, {}
    for m in range(number_of_machines):
        if len(old_seq[m]) > 1:
            m_tardiness[m] = round(float(np.sum(current_sol_df[current_sol_df[:, 1] == m, :][:,4])), 2)
            m_load[m] = round(float(np.max(current_sol_df[current_sol_df[:, 1] == m, :][:,3])), 2)
    max_tard, min_tard, max_load, min_load = max(m_tardiness.values()), min(m_tardiness.values()), max(
        m_load.values()), min(m_load.values())
    m_max_tard, m_max_load = random.choice([k for k, v in m_tardiness.items() if v == max_tard]), random.choice(
        [k for k, v in m_load.items() if v == max_load])
    m_min_tard, m_min_load = random.choice([k for k, v in m_tardiness.items() if v == min_tard]), random.choice(
        [k for k, v in m_load.items() if v == min_load])
    kk = current_sol_df[np.where(current_sol_df[:,1] == m_max_tard)]
    j_max_tard = kk[random.choice([np.where(kk[:,4] == np.max(current_sol_df[current_sol_df[:, 1] == m_max_tard, :][:,4]))[0][0]])][0]
    kk = current_sol_df[np.where(current_sol_df[:,1] == m_min_tard)]
    j_min_tard = kk[random.choice([np.where(kk[:,4] == np.min(current_sol_df[current_sol_df[:, 1] == m_min_tard, :][:,4]))[0][0]])][0]
    new_seq = copy.deepcopy(old_seq)
    new_seq[m_max_tard].remove(j_max_tard)
    new_seq[m_min_tard].insert(0, int(j_max_tard))
    new_seq[m_max_tard].insert(len(new_seq[m_max_tard]), int(j_min_tard))
    new_seq[m_min_tard].remove(j_min_tard)
    return new_seq


def new_neighborhood_int(number_of_machines, current_sol_df, old_seq):
    m_tardiness, m_load = {}, {}
    for m in range(number_of_machines):
        if len(old_seq[m]) > 1:
            m_tardiness[m] = round(float(np.sum(current_sol_df[current_sol_df[:, 1] == m, :][:,4])), 2)
            m_load[m] = round(float(np.max(current_sol_df[current_sol_df[:, 1] == m, :][:,3])), 2)
    max_tard = max(m_tardiness.values())
    m_max_tard = random.choice([k for k, v in m_tardiness.items() if v == max_tard])
    kk = current_sol_df[np.where(current_sol_df[:,1] == m_max_tard)]
    j_max_tard = kk[random.choice([np.where(kk[:,4] == np.max(current_sol_df[current_sol_df[:, 1] == m_max_tard, :][:,4]))[0][0]])][0]
    j_min_tard = kk[random.choice([np.where(kk[:,4] == np.min(current_sol_df[current_sol_df[:, 1] == m_max_tard, :][:,4]))[0][0]])][0]
    new_seq = copy.deepcopy(old_seq)
    pos1 = new_seq[m_max_tard].index(j_max_tard)
    pos2 = new_seq[m_max_tard].index(j_min_tard)
    new_seq[m_max_tard][pos1], new_seq[m_max_tard][pos2] = new_seq[m_max_tard][pos2], new_seq[m_max_tard][pos1]
    return new_seq
