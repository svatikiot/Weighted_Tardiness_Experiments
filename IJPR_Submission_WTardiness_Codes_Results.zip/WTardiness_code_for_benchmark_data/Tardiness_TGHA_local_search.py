import math
import numpy as np
import pandas as pd
from datetime import datetime
import Tardiness_TGHA_CP
import Tardiness_TGHA_calculator
import Tardiness_TGHA_sequence
import time


def local_search_EDD_external(current_sol, num_workers, setups, process, number_of_machines, deadlines):
    # calculate tardiness for each order on each machine without resources
    sol_df = pd.DataFrame()
    machine_tard = {}
    for m in range(number_of_machines):
        new_mach_df, machine_tard[m] = Tardiness_TGHA_calculator.calculator(m, current_sol['M_Seq'], process,
                                                                            setups[m],
                                                                            deadlines)
        sol_df = sol_df.append(new_mach_df)


    # external swaps

    max_machine, min_machine = max(machine_tard, key=machine_tard.get), min(machine_tard, key=machine_tard.get)
    max_tard_job = sol_df.loc[sol_df['Machine'] == max_machine, 'Tardiness'].idxmax()
    new_seq = {}
    new_seq[max_machine], new_seq[min_machine] = current_sol['M_Seq'][max_machine].copy(), current_sol['M_Seq'][
        min_machine].copy()
    new_seq[max_machine].remove(max_tard_job)
    new_seq[min_machine].append(int(max_tard_job))
    m_sequence = {}
    for m in range(number_of_machines):
        if m in [max_machine, min_machine]:
            m_sequence[m] = Tardiness_TGHA_sequence.sequence_dependent_edd(new_seq[m], process.loc[:, m], setups[m],
                                                                           deadlines)
        else:
            m_sequence[m] = current_sol['M_Seq'][m]

    ##############################################################################################################
    # CALL CP function

    final_solution, solution_cp = Tardiness_TGHA_CP.resources_cp(num_workers, new_seq, process, setups, deadlines)

    #############################################################################################################


    return current_sol


def local_search_EDD_internal(current_sol, num_workers, setups, process, number_of_machines, deadlines):
    # calculate tardiness for each order on each machine without resources
    sol_df = pd.DataFrame()
    machine_tard = {}
    for m in range(number_of_machines):
        new_mach_df, machine_tard[m] = Tardiness_TGHA_calculator.calculator(m, current_sol['M_Seq'], process,
                                                                            setups[m],
                                                                            deadlines)
        sol_df = sol_df.append(new_mach_df)

    # internal swaps
    print (sol_df)
    for m in range(number_of_machines):
        sequence = current_sol['Loom_Seq'][m]
        ls_df = sol_df.query('index != 0')
        max_tard_job = ls_df.loc[ls_df['Machine'] == m, 'Tardiness'].idxmax()
        min_tard_job = ls_df.loc[ls_df['Machine'] == m, 'Tardiness'].idxmin()
        print(sequence)
        a, b = sequence.index(max_tard_job), sequence.index(min_tard_job)
        sequence[b], sequence[a] = sequence[a], sequence[b]
        new_mach_df, machine_tard[m] = Tardiness_TGHA_calculator.calculator(m, current_sol['Loom_Seq'], process, setups[m],
                                                                            deadlines)

        print(sequence)
        print(max_tard_job)
        print(min_tard_job)
        asf
        print(sequence)

    # find machine with max and min tardiness
    machine_tard = {}
    for m in range(number_of_machines):
        machine_tard[m] = sol_df.loc[sol_df['Machine'] == m, 'Tardiness'].sum()
    print(machine_tard)


    print(max_machine, min_machine)
    asfaf
    print(EDD_values)
    print(sol_df)

    ##############################################################################################################
    # CALL CP function

    final_solution, solution_cp = Tardiness_TGHA_CP.resources_cp(num_workers, new_seq, process, setups, deadlines)

    #############################################################################################################


    return order_to_add