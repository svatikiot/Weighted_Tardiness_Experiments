import math
import numpy as np
import random
import pandas as pd

pd.set_option("display.max_rows", None, "display.max_columns", None)


def atcs_algorithm(number_of_jobs, num_machines, weights, process_time, setup_times, deadlines, tau, rho, p_avg, s_avg):
    # calculate parameters
    h = s_avg/p_avg
    miu = (number_of_jobs) / num_machines
    k1 = round(1.2 * math.log(miu) - rho, 2)
    if tau < 0.5 or (h < 0.5 and miu > 5):
        k1 -= 0.5
    if tau < 0.8:
        a2 = 1.8
    else:
        a2 = 2
    k2 = round(tau / (a2 * math.sqrt(h)), 2)
    keys = list(range(num_machines))
    m_sequence, previous_job, load = {key: [] for key in keys}, \
                                     dict.fromkeys(range(num_machines), 0), dict.fromkeys(range(num_machines), 0.0)
    job_set = list(range(1, number_of_jobs + 1))
    while len(job_set) > 0:
        # find machine with minimum load
        min_load = min(load.values())
        pos_min = random.choice([k for k, v in load.items() if v == min_load])
        # calculate index for each job in job_set
        index_atcs = dict.fromkeys(range(1, number_of_jobs + 1), -math.inf)
        #print (job_set)
        for j in job_set:
                index_atcs[j] = round(weights[j] / process_time[j, pos_min] * math.exp(
                    -(max(deadlines[j] - process_time[j, pos_min] - load[pos_min], 0)) / (k1 * p_avg)) * math.exp(
                        -setup_times[pos_min][previous_job[pos_min]][j] / (k2 * s_avg)), 4)

        max_ind = max(index_atcs.values())
        job_max = random.choice([k for k, v in index_atcs.items() if v == max_ind])
        assigned_load = dict.fromkeys(range(num_machines), math.inf)
        for m in range(num_machines):
            assigned_load[m] = load[m] + process_time[job_max][m] + setup_times[m][previous_job[m]][j]
        new_load = min(assigned_load.values())
        chosen_machine = random.choice([k for k, v in assigned_load.items() if v == new_load])
        #print (chosen_machine)
        m_sequence[chosen_machine] += [job_max]
        previous_job[chosen_machine] = job_max
        load[chosen_machine] = new_load
        job_set.remove(job_max)
        #print (job_set, j)
    return m_sequence
