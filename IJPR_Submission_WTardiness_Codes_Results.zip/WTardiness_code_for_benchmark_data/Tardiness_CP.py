import math, random
import numpy as np
import pandas as pd
from datetime import datetime
#from docplex.cp.model import CpoModel
import time

pd.set_option('display.max_columns', None, 'display.max_rows', None)

def resources_cp(num_workers, sequence, process_time_assgn, setups, deadlines, weights, sol_cut_off):
    workers = num_workers
    machines = len(sequence)
    jobs = len(process_time_assgn) - 1
    horizon = 20000

    processing_times = [[0.0 for m in range(machines)] for j in range(jobs)]
    setup_times = [[[0.0 for m in range(machines)] for j in range(jobs)] for i in range(jobs)]
    zero_setup = [[0.0 for m in range(machines)] for j in range(jobs)]

    for j in range(jobs):
        for m in range(machines):
            processing_times[j][m] = process_time_assgn[j+1, m]
    for m in setups.keys():
        for i in range(1,len(setups[m])):
            for j in range(1,len(setups[m][i])):
                setup_times[i-1][j-1][m] = setups[m][i][j]
    for m in setups.keys():
        for j in range(len(setups[m][0])):
            zero_setup[j-1][m] = setups[m][0][j]

    neighbourhood = []
    for m in sequence.keys():
        neighbourhood.append([])
        for j in range(len(sequence[m])):
            neighbourhood[m].append(sequence[m][j])

    conversion = []
    for j in deadlines.keys():
        if j > 0:
            conversion.append(int(deadlines[j]))
    due = [conversion[j] for j in range(len(conversion))]
    conversion = []
    for j in weights.keys():
        if j > 0:
            conversion.append(int(weights[j]))
    w = [conversion[j] for j in range(len(conversion))]
    ######################## TO REMOVE AFTER CP IS ADDED #############################
    subproblem = CpoModel()
    setup = {}
    for m in range(machines):
        for i in range(len(neighbourhood[m])):
            if i == 0:
                start = (0, horizon)
                end = (0, horizon)
                size = math.ceil(zero_setup[neighbourhood[m][i]-1][m])
                setup[(m, i)] = subproblem.interval_var(start, end, size, name = "setup"+str(m)+","+str(neighbourhood[m][i]))
            else:
                start = (0, horizon)
                end = (0, horizon)
                size = int(setup_times[neighbourhood[m][i-1]-1][neighbourhood[m][i]-1][m])
                setup[(m, i)] = subproblem.interval_var(start, end, size, name = "setup"+str(m)+","+str(neighbourhood[m][i]))

    completion_times = []
    for m in range(machines):
        completion_times.append([])
        for i in range(len(neighbourhood[m])):
            completion_times[m].append(subproblem.integer_var(0, horizon, "Ct_"+str(m)+","+str(i)))

    tardiness = []
    for i in range(jobs):
        tardiness.append(subproblem.integer_var(0, horizon - due[i], "T_"+str(i)))

    subproblem.add(sum([subproblem.pulse(setup[(m, i)], 1) for m in range(machines) for i in range(len(neighbourhood[m]))]) <= workers)
    for m in range(machines):
        for i in range(len(neighbourhood[m])):
            if i == 0:
                subproblem.add(completion_times[m][i] >= zero_setup[neighbourhood[m][i]-1][m] + processing_times[neighbourhood[m][i]-1][m])
            else:
                subproblem.add(subproblem.start_of(setup[(m, i)]) >= subproblem.end_of(setup[(m, i-1)]) + processing_times[neighbourhood[m][i-1]-1][m])
                subproblem.add(completion_times[m][i] >= subproblem.end_of(setup[(m, i)]) + processing_times[neighbourhood[m][i]-1][m])
            subproblem.add(tardiness[neighbourhood[m][i]-1] >= completion_times[m][i] - deadlines[neighbourhood[m][i]-1])

    total_cost = sum([w[i]*tardiness[i] for i in range(jobs)])
    if sol_cut_off >= 0:
        subproblem.add(total_cost <= sol_cut_off)
    subproblem.add(subproblem.minimize(total_cost))

    sol = subproblem.solve(agent = 'local', execfile='/opt/ibm/ILOG/CPLEX_Studio201/cpoptimizer/bin/x86-64_linux/cpoptimizer', TimeLimit = 1.0, trace_log = False)
    #sol = subproblem.solve(TimeLimit = 1.0, trace_log = False)

    if sol:
        obj_value = 0
        for i in range(jobs):
            obj_value = obj_value + w[i]*sol[tardiness[i]]
    else:
        obj_value = math.inf
    ######################## TO REMOVE AFTER CP IS ADDED #############################
    return obj_value


def resources_cp_with_sol(num_workers, sequence, process_time_assgn, setups, deadlines, weights):
    workers = num_workers
    machines = len(sequence)
    jobs = len(process_time_assgn) - 1
    horizon = 20000

    processing_times = [[0.0 for m in range(machines)] for j in range(jobs)]
    setup_times = [[[0.0 for m in range(machines)] for j in range(jobs)] for i in range(jobs)]
    zero_setup = [[0.0 for m in range(machines)] for j in range(jobs)]

    for j in range(jobs):
        for m in range(machines):
            processing_times[j][m] = process_time_assgn[j+1, m]
    for m in setups.keys():
        for i in range(1,len(setups[m])):
            for j in range(1,len(setups[m][i])):
                setup_times[i-1][j-1][m] = setups[m][i][j]
    for m in setups.keys():
        for j in range(len(setups[m][0])):
            zero_setup[j-1][m] = setups[m][0][j]

    neighbourhood = []
    for m in sequence.keys():
        neighbourhood.append([])
        for j in range(len(sequence[m])):
            neighbourhood[m].append(sequence[m][j])

    conversion = []
    for j in deadlines.keys():
        if j > 0:
            conversion.append(int(deadlines[j]))
    due = [conversion[j] for j in range(len(conversion))]
    conversion = []
    for j in weights.keys():
        if j > 0:
            conversion.append(int(weights[j]))
    w = [conversion[j] for j in range(len(conversion))]

    ######################## TO REMOVE AFTER CP IS ADDED #############################
    subproblem = CpoModel()
    setup = {}
    for m in range(machines):
        for i in range(len(neighbourhood[m])):
            if i == 0:
                start = (0, horizon)
                end = (0, horizon)
                size = math.ceil(zero_setup[neighbourhood[m][i]-1][m])
                setup[(m, i)] = subproblem.interval_var(start, end, size, name = "setup"+str(m)+","+str(neighbourhood[m][i]))
            else:
                start = (0, horizon)
                end = (0, horizon)
                size = int(setup_times[neighbourhood[m][i-1]-1][neighbourhood[m][i]-1][m])
                setup[(m, i)] = subproblem.interval_var(start, end, size, name = "setup"+str(m)+","+str(neighbourhood[m][i]))

    completion_times = []
    for m in range(machines):
        completion_times.append([])
        for i in range(len(neighbourhood[m])):
            completion_times[m].append(subproblem.integer_var(0, horizon, "Ct_"+str(m)+","+str(i)))

    tardiness = []
    for i in range(jobs):
        tardiness.append(subproblem.integer_var(0, horizon - due[i], "T_"+str(i)))

    subproblem.add(sum([subproblem.pulse(setup[(m, i)], 1) for m in range(machines) for i in range(len(neighbourhood[m]))]) <= workers)
    for m in range(machines):
        for i in range(len(neighbourhood[m])):
            if i == 0:
                subproblem.add(completion_times[m][i] >= zero_setup[neighbourhood[m][i]-1][m] + processing_times[neighbourhood[m][i]-1][m])
            else:
                subproblem.add(subproblem.start_of(setup[(m, i)]) >= subproblem.end_of(setup[(m, i-1)]) + processing_times[neighbourhood[m][i-1]-1][m])
                subproblem.add(completion_times[m][i] >= subproblem.end_of(setup[(m, i)]) + processing_times[neighbourhood[m][i]-1][m])
            subproblem.add(tardiness[neighbourhood[m][i]-1] >= completion_times[m][i] - deadlines[neighbourhood[m][i]-1])

    total_cost = sum([w[i]*tardiness[i] for i in range(jobs)])
    subproblem.add(subproblem.minimize(total_cost))

    sol = subproblem.solve(agent = 'local', execfile='/opt/ibm/ILOG/CPLEX_Studio201/cpoptimizer/bin/x86-64_linux/cpoptimizer', TimeLimit = 1.0, trace_log = False)
    #sol = subproblem.solve(TimeLimit = 1.0, trace_log = False)

    obj_value = 0
    for j in range(jobs):
        obj_value = obj_value + w[j]*sol[tardiness[j]]

    start_times = [0.0 for j in range(jobs)]
    end_times = [0.0 for j in range(jobs)]
    jobs_to_machines = [None for j in range(jobs)]
    for m in range(machines):
        for i in range(len(neighbourhood[m])):
            jobs_to_machines[neighbourhood[m][i]-1] = m
            start_times[neighbourhood[m][i]-1] = sol[setup[(m,i)]][0]
            end_times[neighbourhood[m][i]-1] = sol[completion_times[m][i]]

    sol_df = np.zeros((0, 5),float)
    machine_tard = 0
    for j in range(jobs):
        for m in range(machines):
            previous_load, previous_order = 0, 0
            for i in range(len(neighbourhood[m])):
                if j == neighbourhood[m][i]-1:
                    row = [[int(neighbourhood[m][i]), int(m), start_times[neighbourhood[m][i]-1], end_times[neighbourhood[m][i]-1],
                            w[neighbourhood[m][i]-1]*sol[tardiness[neighbourhood[m][i]-1]]]]
                    sol_df = np.append(sol_df, row, axis=0)
    return obj_value, sol_df
