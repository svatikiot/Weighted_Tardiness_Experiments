import random
import numpy as np
import math


def spawning(size, jobs):
    chromosomes = {}
    k = list(range(1, jobs + 1))
    for i in range(size):
        seq = list(np.random.permutation(k))
        chromosomes[i] = {'Order': seq, 'Obj': 0}
    return chromosomes
